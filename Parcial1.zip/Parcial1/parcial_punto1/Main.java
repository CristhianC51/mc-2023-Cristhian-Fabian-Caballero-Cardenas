package parcial_punto1;

import java.util.HashSet;
import java.util.Set;

public class Main {

    public static void main(String[] args) {

        Set<Integer> A = new HashSet<>();
        for (int i = 7; i <= 30; i++) {
            A.add(i);
        }
        
        System.out.println("Conjunto A: " + A);

        Set<Integer> B = new HashSet<>();
        B.add(2);
        B.add(5);
        B.add(7);
        B.add(9);
        B.add(15);
        B.add(22);
        B.add(33);
        
        System.out.println("Conjunto B: " + B);

        Set<Integer> C = new HashSet<>();
        for (int i = 3; i < 30; i++) {
            if (i % 3 == 1) {
                C.add(i);
            }
        }
        
        System.out.println("Conjunto C: " + C);
        
        Set<Integer> ejercicio1 = union(interseccion(A, C), diferenciaSimetrica(A,B));
        System.out.println("(A ∩ C) ∪ (A⨁B) = " + ejercicio1);

        Set<Integer> ejercicio2 = interseccion(diferenciaSimetrica(union(A,C), B),diferenciaAB(A,C));
        System.out.println("((A ∪ C)⨁B) ∩ (A − C) = " + ejercicio2);

        Set<Integer> ejercicio3 = interseccion(diferenciaAB(union(A,B),interseccion(A,C)), union(union(A,B),C));
        System.out.println("((A ∪ B) − (A ∩ C)) ∩ (A ∪ B ∪ C) = " + ejercicio3);
    }

    public static Set<Integer> union(Set<Integer> conjuntoA, Set<Integer> conjuntoB) {
        Set<Integer> resul = new HashSet<>(conjuntoA);
        resul.addAll(conjuntoB);
        return resul;
    }

    public static Set<Integer> interseccion(Set<Integer> conjuntoA, Set<Integer> conjuntoB) {
        Set<Integer> resul = new HashSet<>(conjuntoA);
        resul.retainAll(conjuntoB);
        return resul;
    }

    public static Set<Integer> diferenciaAB(Set<Integer> conjuntoA, Set<Integer> conjuntoB) {
        Set<Integer> resul = new HashSet<>(conjuntoA);
        resul.removeAll(conjuntoB);

        return resul;
    }

    public static Set<Integer> diferenciaBA(Set<Integer> conjuntoA, Set<Integer> conjuntoB) {
        Set<Integer> resul = new HashSet<>(conjuntoB);
        resul.removeAll(conjuntoA);

        return resul;
    }

    public static Set<Integer> diferenciaSimetrica(Set<Integer> conjuntoA, Set<Integer> conjuntoB) {
        Set<Integer> resul = new HashSet<>(conjuntoA);
        resul.removeAll(conjuntoB);

        Set<Integer> resul2 = new HashSet<>(conjuntoB);
        resul2.removeAll(conjuntoA);

        Set<Integer> resulfinal = new HashSet<>();
        resulfinal.addAll(resul);
        resulfinal.addAll(resul2);
        return resulfinal;
    }
}
